int funcion1(){
int k;
int g 		//error por no tener ;
a = a * c 	//error por no tener ;
a = a * funcion(8);
if (y>=0) {
x= a+b;
} 
else {
x= a+b;
}
else { 		//deberia dar error por doble uso de else
x= a+b;
}

if x==3 {	//deberia dar error por expresion fuera de parentesis
x= a+b;
}
else {
x--;
}
}

int funcion4(int, int) {		//no se permite solo los tipos
if ( (x<7) && (x>2) ){
x= g+6;
}
while ( ){ 	//debe dar error porque falta expresion
x= a+b;
break;
}

for (x=0; ) { 	//error pues hay solamente una expresion
x= a+b;
break;
}
}
